#include <linux/kernel.h>

asmlinkage long sys_greetings(void)
{
        printk("Greeting from kernel and team no %d\n", 9);
        return 0;
}
